package com.example.kanban.controller;

import com.example.kanban.model.Tarefa;
import com.example.kanban.service.TarefaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/tarefa")
public class TarefaController {

    @Autowired
    private TarefaService tarefaService;

    @GetMapping
    public List<Tarefa> mostrarTudo() {
        return tarefaService.findAll();
    }

    @GetMapping("/status/{status}")
    public List<Tarefa> mostrarPorStatus(@PathVariable String status) {
        return tarefaService.findAllByStatus(status);
    }

    @GetMapping("/prioridade/{prioridade}")
    public List<Tarefa> filtrarPorPrioridade(@PathVariable String prioridade) {
        return tarefaService.findAllByPrioridade(prioridade);
    }

    @GetMapping("/atrasadas")
    public List<Tarefa> listarAtrasadas() {
        return tarefaService.findOverdue();
    }

    @PostMapping
    public Tarefa criarTarefa(@RequestBody Tarefa tarefa) {
        tarefa.setStatus("A FAZER");
        return tarefaService.salvar(tarefa);
    }

    @PutMapping("/{id}/editar")
    public Tarefa editarTarefa(@PathVariable Long id, @RequestBody Tarefa tarefaAtualizada) {
        Tarefa tarefa = tarefaService.updateTarefa(id, tarefaAtualizada);
        if (tarefa == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Solicitação não encontrada");
        }
        return tarefa;
    }

    @PutMapping
    public Tarefa editarTarefa2(@RequestBody Tarefa tarefa) {
        return tarefaService.salvar(tarefa);
    }

    @PutMapping("/{id}/avancarPrioridade")
    public Tarefa avancarPrioridade(@PathVariable Long id) {
        Tarefa tarefa = tarefaService.acharId(id);
        if (tarefa == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Tarefa não encontrada");
        }

        switch (tarefa.getPrioridade()) {
            case "BAIXA":
                tarefa.setPrioridade("MÉDIA");
                break;
            case "MÉDIA":
                tarefa.setPrioridade("ALTA");
                break;
            default:
                return tarefa;
        }
        return tarefaService.salvar(tarefa);
    }

    @PutMapping("/{id}/avancarStatus")
    public Tarefa avancarStatus(@PathVariable Long id) {
        Tarefa tarefa = tarefaService.acharId(id);
        if (tarefa == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Tarefa não encontrada");
        }

        switch (tarefa.getStatus()) {
            case "A FAZER":
                tarefa.setStatus("FAZENDO");
                break;
            case "FAZENDO":
                tarefa.setStatus("CONCLUÍDO");
                break;
            default:
                return tarefa;
        }
        return tarefaService.salvar(tarefa);
    }

    @DeleteMapping("/{id}")
    public void deletarTarefa(@PathVariable Long id) {
        tarefaService.deletarporId(id);
    }
}
