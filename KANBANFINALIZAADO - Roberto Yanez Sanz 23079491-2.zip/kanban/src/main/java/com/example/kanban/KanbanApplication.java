package com.example.kanban;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KanbanApplication {

	public static void main(String[] args) {
		SpringApplication.run(KanbanApplication.class, args);
	}
}

/*
UTILIZAR O INSOMNIA (PELO POSTMAN PODE DAR ERRO)

TODAS AS ROTAS:

REGISTRAR USUÁRIO = POST localhost:8090/auth/register

{
    "login": "teste",
    "password": "123",
    "role": "ADMIN"
} (inserir em body tipo json)

LOGIN E TOKEN = POST localhost:8090/auth/login

{
    "login": "teste",
    "password": "123"
}

EM TODAS AS REQUISIÇÕES COLOCAR O TOKEN NO AUTH -> BEARER TOKEN, INSERIR O TOKEN E EM PREFIX "BEARER"

CRIAR TAREFA = POST localhost:8090/tarefa
{
  "titulo": "TAREFA TESTE",
  "descricao": "Completar a atividade testeteste",
  "dataCriacao": "2024-11-18",
  "dataLimite": "2024-12-01",
  "prioridade": "BAIXA"
}

EDITAR TAREFA = PUT localhost:8090/tarefa/1/editar

{
  "titulo": "TAREFA TESTEEDITADA",
  "descricao": "Completar a atividade testeteste",
  "dataCriacao": "2024-11-18",
  "dataLimite": "2024-16-01",
  "prioridade": "BAIXA"
}

MUDAR STATUS = PUT localhost:8090/tarefa/1/avancarStatus
MUDAR PRIORIDADE = PUT localhost:8090/tarefa/1/avancarPrioridade

EXCLUIR TAREFA = DELETE localhost:8090/tarefa/1

MOSTRAR TODAS TAREFAS = GET Localhost:8090/tarefa

MOSTRAR TAREFAS POR STATUS = GET localhost:8090/tarefa/status/A FAZER

MOSTRAR TAREFAS POR PRIORIDADE = GET localhost:8090/tarefa/prioridade/BAIXA

MOSTRAR TAREFAS ATRASADAS = GET localhost:8090/tarefa/atrasadas

 */