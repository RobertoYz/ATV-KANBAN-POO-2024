package com.example.kanban.user;

public record LoginResponseDTO(String token) {
}
