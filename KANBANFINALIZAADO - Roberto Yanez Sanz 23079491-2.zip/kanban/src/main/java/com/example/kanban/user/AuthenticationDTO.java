package com.example.kanban.user;

public record AuthenticationDTO(String login, String password) {
}
