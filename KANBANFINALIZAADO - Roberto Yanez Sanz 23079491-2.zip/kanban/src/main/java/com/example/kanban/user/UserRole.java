package com.example.kanban.user;

public enum UserRole {

    ADMIN("admin"),
    USERS("user");

    private String role;

    UserRole(String role){
        this.role = role;
    }

    public String gerRole(){
        return role;
    }
}
