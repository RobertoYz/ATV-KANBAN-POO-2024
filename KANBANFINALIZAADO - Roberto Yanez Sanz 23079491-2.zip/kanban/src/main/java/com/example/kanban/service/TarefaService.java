package com.example.kanban.service;

import com.example.kanban.model.Tarefa;
import com.example.kanban.repository.TarefaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TarefaService {

    @Autowired
    private TarefaRepository tarefaRepository;

    public List<Tarefa> findAll() {
        return tarefaRepository.findAll()
                .stream()
                .sorted(Comparator.comparing(Tarefa::getPrioridade).thenComparing(Tarefa::getDataLimite))
                .collect(Collectors.toList());
    }

    public List<Tarefa> findAllByStatus(String status) {
        return tarefaRepository.findAll()
                .stream()
                .filter(tarefa -> tarefa.getStatus().equalsIgnoreCase(status))
                .sorted(Comparator.comparing(Tarefa::getPrioridade).thenComparing(Tarefa::getDataLimite))
                .collect(Collectors.toList());
    }

    public List<Tarefa> findAllByPrioridade(String prioridade) {
        return tarefaRepository.findAll()
                .stream()
                .filter(tarefa -> tarefa.getPrioridade().equalsIgnoreCase(prioridade))
                .sorted(Comparator.comparing(Tarefa::getDataLimite))
                .collect(Collectors.toList());
    }

    public List<Tarefa> findOverdue() {
        LocalDate hoje = LocalDate.now();
        return tarefaRepository.findAll()
                .stream()
                .filter(tarefa -> tarefa.getDataLimite() != null && tarefa.getDataLimite().isBefore(hoje) && !tarefa.getStatus().equalsIgnoreCase("CONCLUÍDO"))
                .collect(Collectors.toList());
    }


    public Tarefa acharId(Long id) {
        return tarefaRepository.findById(id).orElse(null);
    }

    public Tarefa salvar(Tarefa tarefa) {
        return tarefaRepository.save(tarefa);
    }

    public void deletarporId(Long id) {
        tarefaRepository.deleteById(id);
    }

    public Tarefa updateTarefa(Long id, Tarefa tarefaAtualizada) {
        return tarefaRepository.findById(id).map(tarefa -> {
            tarefa.setTitulo(tarefaAtualizada.getTitulo());
            tarefa.setDescricao(tarefaAtualizada.getDescricao());
            tarefa.setDataCriacao(tarefaAtualizada.getDataCriacao());
            tarefa.setPrioridade(tarefaAtualizada.getPrioridade());
            tarefa.setStatus(tarefaAtualizada.getStatus());
            tarefa.setDataLimite(tarefaAtualizada.getDataLimite());
            return tarefaRepository.save(tarefa);
        }).orElse(null);
    }
}
