package com.example.kanban.user;

public record RegisterDTO(String login, String password, UserRole role) {
}
